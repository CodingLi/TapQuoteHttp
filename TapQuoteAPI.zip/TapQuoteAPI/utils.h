#pragma once

#include <iostream>
#include <string.h>

#include "MyData.h"

int ReadExchangeConf(char *path);
int ReadIpConf(char *path);