#include "TapQuoteAPI.h"
#include "TapAPIError.h"
#include "Quote.h"
#include "QuoteConfig.h"

#include "utils.h"



#pragma comment(lib,"ws2_32.lib")

using namespace std;




char ip[20] = { 0 };
char port[5] = { 0 };
char url_post[MAX_PATH] = { 0 };


SOCKET sockClient[IP_NUM];
SOCKADDR_IN addrSrv[IP_NUM];



char exchange_tmp[EXCHANGE_NUM][EXCHANGE_LEN] = { 0 };
char commodity_tmp[EXCHANGE_NUM][EXCHANGE_LEN] = { 0 };
char contract_tmp[EXCHANGE_NUM][EXCHANGE_LEN] = { 0 };
int exchange_count = 0;




DWORD WINAPI ThreadFunc(LPVOID p)
{
	//printf("Create Thread  %d...\n", GetCurrentThreadId());
	PQuote_Data pmyQuoteData = (PQuote_Data)p;
	//printf("%s:%s:%s\n", pmyQuoteData->exchange_no, pmyQuoteData->commodity_no, pmyQuoteData->contract_no);
	pmyQuoteData->pQuote->RunTest(pmyQuoteData->exchange_no, pmyQuoteData->commodity_no, pmyQuoteData->contract_no);
	//printf("End  %d...\n", GetCurrentThreadId());
	if (pmyQuoteData != NULL)
	{
		delete pmyQuoteData;
	}
	return 0;
}

int GetData()
{
	//ȡ��API�İ汾��Ϣ
	cout << GetTapQuoteAPIVersion() << endl;

	//����APIʵ��
	TAPIINT32 iResult = TAPIERROR_SUCCEED;
	TapAPIApplicationInfo stAppInfo;
	strcpy(stAppInfo.AuthCode, DEFAULT_AUTHCODE);
	strcpy(stAppInfo.KeyOperationLogPath, "");
	ITapQuoteAPI *pAPI = CreateTapQuoteAPI(&stAppInfo, iResult);
	if (NULL == pAPI) {
		cout << "����APIʵ��ʧ�ܣ������룺" << iResult << endl;
		return -1;
	}

	//�趨ITapQuoteAPINotify��ʵ���࣬�����첽��Ϣ�Ľ���
	Quote objQuote;
	pAPI->SetAPINotify(&objQuote);


	//�������ԣ���������;
	objQuote.SetAPI(pAPI);
	//objQuote.SetSocket(socketClient);

	int ret = objQuote.InitLogin();
	if (ret == -1)
	{
		return -1;
	}


	for (int i = 0; i < exchange_count; i++)
	{

		//Quote_Data myQuoteData;
		PQuote_Data pQuoteData = new Quote_Data;
		//printf("%x\n", pQuoteData);
		memset(pQuoteData, 0, sizeof(Quote_Data));
		pQuoteData->pQuote = &objQuote;
		strcpy(pQuoteData->exchange_no, exchange_tmp[i]);
		strcpy(pQuoteData->commodity_no, commodity_tmp[i]);
		strcpy(pQuoteData->contract_no, contract_tmp[i]);
		HANDLE hThread;
		DWORD  threadId;
		//printf("%s:%s:%s\n", pQuoteData->exchange_no, pQuoteData->commodity_no, pQuoteData->contract_no);
		//hThread = CreateThread(NULL, 0, ThreadFunc, (LPVOID)&myQuoteData, 0, &threadId);
		QueueUserWorkItem(ThreadFunc, (LPVOID)pQuoteData, WT_EXECUTEDEFAULT);
	}

	while (1)
	{
		Sleep(1);
	}
	return 1;
}



int main(int argc, char* argv[])
{

	//���ȶ�ȡ�����ļ�;
	ReadIpConf("ip_set.txt");
	ReadExchangeConf("exchange.txt");
	//system("pause");
	//return 1;

	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	wVersionRequested = MAKEWORD(2, 2);
	err = WSAStartup(wVersionRequested, &wsaData);
	if (0 != err)
	{
		cout << " error = " << err << endl;
		return -1; // ����ֵΪ���ʱ���Ǳ�ʾ�ɹ�����WSAStartup  
	}

	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
	{
		WSACleanup();
		return -1;
	}

	// ����socket������������ʽ�׽��֣������׽��ֺ�sockClient 
	// ���׽���sockClient��Զ����������  
	for (int i = 0; i < IP_NUM; i++)
	{
		sockClient[i] = socket(AF_INET, SOCK_STREAM, 0);
		addrSrv[i].sin_addr.S_un.S_addr = inet_addr(ip);
		addrSrv[i].sin_family = AF_INET;
		addrSrv[i].sin_port = htons(atoi(port));
		err = connect(sockClient[i], (SOCKADDR*)&addrSrv[i], sizeof(SOCKADDR));
		if (err == SOCKET_ERROR)
		{
			printf("%d : failed to connect ... \n", i);
		}
		else
		{
			printf("%d : ****connecting******* ... \n", i);
		}
	}

	GetData();

	return 0;
}