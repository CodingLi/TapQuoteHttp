#include "Quote.h"
#include "TapAPIError.h"
#include "QuoteConfig.h"
#include "utils.h"
using namespace std;



extern SOCKET sockClient[IP_NUM];
extern SOCKADDR_IN addrSrv[IP_NUM];

extern char ip[20];
extern char port[5];
extern char url_post[MAX_PATH];

//extern char exchange_tmp[EXCHANGE_NUM][EXCHANGE_LEN];
//extern char commodity_tmp[EXCHANGE_NUM][EXCHANGE_LEN];
//extern char contract_tmp[EXCHANGE_NUM][EXCHANGE_LEN];
//extern int exchange_count;


Quote::Quote(void):
	m_pAPI(NULL),
	m_bIsAPIReady(false)
{
}


Quote::~Quote(void)
{
}


void Quote::SetAPI(ITapQuoteAPI *pAPI)
{
	m_pAPI = pAPI;
}


//void Quote::SetSocket(SOCKET sClient)
//{
//	sockClient = sClient;
//}
//--
int Quote::InitLogin()
{
	InitializeCriticalSection(&g_cs);
	if (NULL == m_pAPI) {
		cout << "Error: m_pAPI is NULL." << endl;
		return -1;
	}

	TAPIINT32 iErr = TAPIERROR_SUCCEED;


	//�趨������IP���˿�
	iErr = m_pAPI->SetHostAddress(DEFAULT_IP, DEFAULT_PORT);
	if (TAPIERROR_SUCCEED != iErr) {
		cout << "SetHostAddress Error:" << iErr << endl;
		return -1;
	}

	//��¼������
	TapAPIQuoteLoginAuth stLoginAuth;
	memset(&stLoginAuth, 0, sizeof(stLoginAuth));
	strcpy(stLoginAuth.UserNo, DEFAULT_USERNAME);
	strcpy(stLoginAuth.Password, DEFAULT_PASSWORD);
	stLoginAuth.ISModifyPassword = APIYNFLAG_NO;
	stLoginAuth.ISDDA = APIYNFLAG_NO;
	iErr = m_pAPI->Login(&stLoginAuth);
	if (TAPIERROR_SUCCEED != iErr) {
		cout << "Login Error:" << iErr << endl;
		return -1;
	}


	//�ȴ�APIReady
	m_Event.WaitEvent();
	if (!m_bIsAPIReady) {
		return -1;
	}
	return 1;
}

void Quote::RunTest(char *exchange_no, char *commodity_no, char *contract_no)
{
	//printf("RunTest currentId = %d\n", GetCurrentThreadId());
	TAPIINT32 iErr = TAPIERROR_SUCCEED;

	m_uiSessionID = 0;
	TapAPICommodity com;
	memset(&com, 0, sizeof(com));
	strcpy(com.ExchangeNo, exchange_no);
	strcpy(com.CommodityNo, commodity_no);
	com.CommodityType = DEFAULT_COMMODITY_TYPE;
	m_pAPI->QryContract(&m_uiSessionID, &com);


	//��������
	TapAPIContract stContract;
	memset(&stContract, 0, sizeof(stContract));
	strcpy(stContract.Commodity.ExchangeNo, exchange_no);
	stContract.Commodity.CommodityType = DEFAULT_COMMODITY_TYPE;
	strcpy(stContract.Commodity.CommodityNo, commodity_no);
	strcpy(stContract.ContractNo1, contract_no);
	stContract.CallOrPutFlag1 = TAPI_CALLPUT_FLAG_NONE;
	stContract.CallOrPutFlag2 = TAPI_CALLPUT_FLAG_NONE;
	m_uiSessionID = 0;
	iErr = m_pAPI->SubscribeQuote(&m_uiSessionID, &stContract);
	if (TAPIERROR_SUCCEED != iErr) {
		cout << "SubscribeQuote Error!!!:" << iErr << endl;
		return;
	}

	while (true) {
		m_Event.WaitEvent();
	}
}
//void Quote::RunTest()
//{
//	if(NULL == m_pAPI) {
//		cout << "Error: m_pAPI is NULL." << endl;
//		return;
//	}
//
//	TAPIINT32 iErr = TAPIERROR_SUCCEED;
//
//
//	//�趨������IP���˿�
//	iErr = m_pAPI->SetHostAddress(DEFAULT_IP, DEFAULT_PORT);
//	if(TAPIERROR_SUCCEED != iErr) {
//		cout << "SetHostAddress Error:" << iErr <<endl;
//		return;
//	}
//
//	//��¼������
//	TapAPIQuoteLoginAuth stLoginAuth;
//	memset(&stLoginAuth, 0, sizeof(stLoginAuth));
//	strcpy(stLoginAuth.UserNo, DEFAULT_USERNAME);
//	strcpy(stLoginAuth.Password, DEFAULT_PASSWORD);
//	stLoginAuth.ISModifyPassword = APIYNFLAG_NO;
//	stLoginAuth.ISDDA = APIYNFLAG_NO;
//	iErr = m_pAPI->Login(&stLoginAuth);
//	if(TAPIERROR_SUCCEED != iErr) {
//		cout << "Login Error:" << iErr <<endl;
//		return;
//	}
//	
//
//	//�ȴ�APIReady
//	m_Event.WaitEvent();
//	if (!m_bIsAPIReady){
//		return;
//	}
//
//	m_uiSessionID = 0;
//	TapAPICommodity com;
//	memset(&com, 0, sizeof(com));
//	strcpy(com.ExchangeNo,DEFAULT_EXCHANGE_NO);
//	strcpy(com.CommodityNo,DEFAULT_COMMODITY_NO);
//	com.CommodityType =DEFAULT_COMMODITY_TYPE;
//	m_pAPI->QryContract(&m_uiSessionID,&com);
//
//
//	//��������
//	TapAPIContract stContract;
//	memset(&stContract, 0, sizeof(stContract));
//	strcpy(stContract.Commodity.ExchangeNo, DEFAULT_EXCHANGE_NO);
//	stContract.Commodity.CommodityType = DEFAULT_COMMODITY_TYPE;
//	strcpy(stContract.Commodity.CommodityNo, DEFAULT_COMMODITY_NO);
//	strcpy(stContract.ContractNo1, DEFAULT_CONTRACT_NO);
//	stContract.CallOrPutFlag1 = TAPI_CALLPUT_FLAG_NONE;
//	stContract.CallOrPutFlag2 = TAPI_CALLPUT_FLAG_NONE;
//	m_uiSessionID = 0;
//	iErr = m_pAPI->SubscribeQuote(&m_uiSessionID, &stContract);
//	if(TAPIERROR_SUCCEED != iErr) {
//		cout << "SubscribeQuote Error:" << iErr <<endl;
//		return;
//	}
//
//        while(true) {
//                m_Event.WaitEvent();
//        }
//}



void TAP_CDECL Quote::OnRspLogin(TAPIINT32 errorCode, const TapAPIQuotLoginRspInfo *info)
{
	if(TAPIERROR_SUCCEED == errorCode) {
		cout << "��¼�ɹ����ȴ�API��ʼ��..." << endl;
		m_bIsAPIReady = true;

	} else {
		cout << "��¼ʧ�ܣ�������:" << errorCode << endl;
		m_Event.SignalEvent();	
	}
}

void TAP_CDECL Quote::OnAPIReady()
{
	cout << "API��ʼ�����" << endl;
	m_Event.SignalEvent();	
}

void TAP_CDECL Quote::OnDisconnect(TAPIINT32 reasonCode)
{
	cout << "API�Ͽ�,�Ͽ�ԭ��:"<<reasonCode << endl;
}

void TAP_CDECL Quote::OnRspQryCommodity(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIQuoteCommodityInfo *info)
{
	//cout << __FUNCTION__ << " is called." << endl;
}

void TAP_CDECL Quote::OnRspQryContract(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIQuoteContractInfo *info)
{
	//cout << __FUNCTION__ << " is called." << endl;

	//cout << "��Լ:" << info->Contract.Commodity.CommodityNo << info->Contract.ContractNo1 << endl;
}


void TAP_CDECL Quote::OnRspSubscribeQuote(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIQuoteWhole *info)
{
	//printf("currentId = %d\n", GetCurrentThreadId());
	if (TAPIERROR_SUCCEED == errorCode)
	{
		cout << "���鶩�ĳɹ� --";
		cout << "��Լ:" << info->Contract.Commodity.CommodityNo << info->Contract.ContractNo1 << endl;
		if (NULL != info)
		{
			cout << info->DateTimeStamp << " "
				<< info->Contract.Commodity.ExchangeNo << " "
				<< info->Contract.Commodity.CommodityType << " "
				<< info->Contract.Commodity.CommodityNo << " "
				<< info->Contract.ContractNo1 << " "
				// ...
				<< info->QChangeRate << " "
				<< info->QChangeValue << " "
				<< info->QHighPrice << " "
				<< info->QLowPrice << " "
				<< info->QLimitUpPrice << " "
				<< info->QLimitDownPrice << " "


				<< info->QLastPrice << " "
				<< info->QTotalQty << " "
				<< info->QPositionQty << " "
				<< info->QOpeningPrice << " "
				<< info->QSwing << " "

				<< info->QBidPrice[0] << " "
				<< info->QBidQty[0] << " "
				<< info->QAskPrice[0] << " "
				<< info->QAskQty[0]
				// ...		
				<<endl;
		}

	} else{
		cout << "���鶩��ʧ�ܣ������룺" << errorCode ;
		cout << "��Լ:" << info->Contract.Commodity.CommodityNo << info->Contract.ContractNo1 << endl;
		
	}
}

void TAP_CDECL Quote::OnRspUnSubscribeQuote(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIContract *info)
{
	//cout << __FUNCTION__ << " is called." << endl;
}

char * float2str(float val, int precision, char *buf)
{
	char *cur, *end;
	//int precision = 0;
	sprintf(buf, "%.6lf", val);
	if (precision < 6) {
		cur = buf + strlen(buf) - 1;
		end = cur - 6 + precision;
		while ((cur > end) && (*cur == '0')) {
			*cur = '\0';
			cur--;
		}
	}

	return buf;
}

//�Ͽ���������;
DWORD WINAPI ReconnectThread(LPVOID p)
{
	int index = (int)(p);
	closesocket(sockClient[index]);
	sockClient[index] = socket(AF_INET, SOCK_STREAM, 0);
	int err = connect(sockClient[index], (SOCKADDR*)&addrSrv[index], sizeof(SOCKADDR));
	if (err == SOCKET_ERROR)
	{
		printf("%d : failed to connect, error code = %d\n", index, GetLastError());
	}
	else
	{
		printf("%d : ****connecting*******..\n", index);
	}

	return 0;
}


void TAP_CDECL Quote::OnRtnQuote(const TapAPIQuoteWhole *info)
{

	if (NULL != info)
	{
		//cout << info->DateTimeStamp << " "
		//	<< info->Contract.Commodity.ExchangeNo << " "
		//	<< info->Contract.Commodity.CommodityType << " "
		//	<< info->Contract.Commodity.CommodityNo << " "
		//	<< info->Contract.ContractNo1 << " "
		//	// ...
		//	<< info->QChangeRate << " "
		//	<< info->QChangeValue << " "
		//	<< info->QHighPrice << " "
		//	<< info->QLowPrice << " "
		//	<< info->QLimitUpPrice << " "
		//	<< info->QLimitDownPrice << " "


		//	<< info->QLastPrice << " "
		//	<< info->QTotalQty << " "
		//	<< info->QPositionQty << " "
		//	<< info->QOpeningPrice << " "
		//	<< info->QSwing << " "

		//	<< info->QBidPrice[0] << " "
		//	<< info->QBidQty[0] << " "
		//	<< info->QAskPrice[0] << " "
		//	<< info->QAskQty[0]
		//	// ...		
		//	<< endl;
		try
		{
			char tempData[500] = { 0 };
			Send_Data send_data;
			memset(&send_data, 0, sizeof(send_data));
			memset(tempData, 0, 500);
			float2str(info->QChangeRate, 2, send_data.QChangeRate);
			float2str(info->QChangeValue, 2, send_data.QChangeValue);
			float2str(info->QLowPrice, 2, send_data.QLowPrice);
			float2str(info->QHighPrice, 2, send_data.QHighPrice);
			float2str(info->QLimitUpPrice, 2, send_data.QLimitUpPrice);
			float2str(info->QLimitDownPrice, 2, send_data.QLimitDownPrice);

			float2str(info->QLastPrice, 2, send_data.QLastPrice);
			ltoa(info->QTotalQty, send_data.QTotalQty, 10);
			ltoa(info->QPositionQty, send_data.QPositionQty, 10);
			float2str(info->QOpeningPrice, 2, send_data.QOpeningPrice);
			float2str(info->QSwing, 2, send_data.QSwing);

			float2str(info->QBidPrice[0], 2, send_data.QBidPrice);
			ltoa(info->QBidQty[0], send_data.QBidQty, 10);
			float2str(info->QAskPrice[0], 2, send_data.QAskPrice);
			ltoa(info->QAskQty[0], send_data.QAskQty, 10);

			//�������ݸ�ʽ
			strcat(tempData, info->Contract.Commodity.CommodityNo);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, info->Contract.ContractNo1);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");


			strcat(tempData, send_data.QChangeRate);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QChangeValue);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QHighPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QLowPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QLimitUpPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QLimitDownPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");

			strcat(tempData, send_data.QLastPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QTotalQty);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QPositionQty);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QOpeningPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QSwing);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QBidPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QBidQty);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QAskPrice);
			tempData[strlen(tempData)] = 0;
			strcat(tempData, "|");
			strcat(tempData, send_data.QAskQty);
			tempData[strlen(tempData)] = 0;

			char pHttpPost[MAX_PATH] = "POST %s HTTP/1.1\r\n"
				"Host: %s\r\n"
				"Content-Type: application/x-www-form-urlencoded\r\n"
				"Content-Length: %d\r\n\r\n"
				"%s";

			char msg[500] = { 0 };
			memset(msg, 0, 500);
			strcat(msg, "data=");
			strcat(msg, tempData);

			char strHttpPost[1024] = { 0 };
			memset(strHttpPost, 0, 1024);
			sprintf(strHttpPost, pHttpPost, url_post, ip, strlen(msg), msg);

			int len = strlen(strHttpPost);

			EnterCriticalSection(&g_cs);
			//�����ٽ���������������߳���ȴ�;

			for (int i = 0; i < IP_NUM; i++)
			{
				//printf("send len = %d \n", len);
				int nRet = send(sockClient[i], (char*)&strHttpPost, len, 0);
				if (nRet == SOCKET_ERROR)
				{
					printf("%d: failed to send data, error code = %d, try to reconnect ....\n", i, GetLastError());
					QueueUserWorkItem(ReconnectThread, (LPVOID)i, WT_EXECUTEDEFAULT);
				}
				printf("send len = %d\n", nRet);
			}

			LeaveCriticalSection(&g_cs);//�˳��ٽ����������߳̿��Խ�����;
		}
		catch (...)
		{
			printf("catch code = %d\n", GetLastError());
		}
	}
}