#include "utils.h"

extern char ip[20];
extern char port[5];
extern char url_post[MAX_PATH];

extern char exchange_tmp[EXCHANGE_NUM][EXCHANGE_LEN];
extern char commodity_tmp[EXCHANGE_NUM][EXCHANGE_LEN];
extern char contract_tmp[EXCHANGE_NUM][EXCHANGE_LEN];
extern int exchange_count;



int ReadExchangeConf(char * path)
{

	char buf[100] = { 0 };
	int i = 0;

	FILE *fp = fopen(path, "r");
	if (fp == NULL)
	{
		printf("failed to open exchange.txt!!!\n");
		return -1;
	}

	while (!feof(fp))
	{
		memset(buf, 0, 100);
		fscanf(fp, "%s", &buf);

		char *ptr;
		ptr = strtok(buf, ":");
		if (ptr == NULL)
		{
			continue;
		}
		strcpy(exchange_tmp[i], ptr);

		ptr = strtok(NULL, ":");
		if (ptr == NULL)
		{
			continue;
		}
		strcpy(commodity_tmp[i], ptr);

		ptr = strtok(NULL, ":");
		if (ptr == NULL)
		{
			continue;
		}
		strcpy(contract_tmp[i], ptr);
		i++;
	}

	exchange_count = i;
	//printf("exchange_count = %d\n", exchange_count);

	//for (int j = 0; j < exchange_count; j++)
	//{
	//	printf("exchange_no = %s -- commodity_no = %s --- contract_no = %s\n", exchange_tmp[j], commodity_tmp[j], contract_tmp[j]);
	//}
	return exchange_count;
}



int ReadIpConf(char * path)
{
	FILE *fp = fopen(path, "r");
	if (fp == NULL)
	{
		printf("failed to open ip_set.txt!!!\n");
		return -1;
	}

	fgets(ip, MAX_LINE, fp);
	ip[strlen(ip) - 1] = 0;
	fgets(port, MAX_LINE, fp);
	port[strlen(port) - 1] = 0;
	fgets(url_post, MAX_LINE, fp);
	url_post[strlen(url_post) - 1] = 0;
	//cout << ip_post << endl;
	//cout << port_post << endl;
	//cout << url_post << endl;
	fclose(fp);
}